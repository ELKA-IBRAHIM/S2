Dans le dossier, vous trouverez 

Le compte rendu du projet

3 programmes de résolutions:
    - Problème en 2D résolu par différences finies
    - Problème en 3D résolu avec les sensibilités
    - Problème en 3D résolu par différences finies avec de la récursivité

1 programmes de créations des données de façon aléatoire

3 fichiers avec des données de test qui fonctionne (un pour chaque résolution de problèmes)


Jules FARNAULT
Paul BOULLIER
